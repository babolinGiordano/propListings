import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-listing',
  templateUrl: './edit-listing.component.html',
  styleUrls: ['./edit-listing.component.css']
})
export class EditListingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
