Install dependencies
$ npm install

run app
$ ng serve